import 'package:sublime_groceria/repositories/sublimebaserepository.dart';

class RecipesRepository extends SublimeBaseRepository {
  RecipesRepository() : super();
}
