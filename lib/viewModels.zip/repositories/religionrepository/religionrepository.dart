import 'package:sublime_groceria/repositories/sublimebaserepository.dart';

class ReligionRepository extends SublimeBaseRepository {
  ReligionRepository() : super();
}
