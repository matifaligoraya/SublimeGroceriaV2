// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nutration.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$NutrationImpl _$$NutrationImplFromJson(Map<String, dynamic> json) =>
    _$NutrationImpl(
      calories: json['calories'] as String?,
      serving_size_g: json['serving_size_g'] as String?,
      fat_total_g: json['fat_total_g'] as String?,
      fat_saturated_g: json['fat_saturated_g'] as String?,
      protein_g: json['protein_g'] as String?,
      sodium_mg: json['sodium_mg'] as String?,
      potassium_mg: json['potassium_mg'] as String?,
      cholesterol_mg: json['cholesterol_mg'] as String?,
      fiber_g: json['fiber_g'] as String?,
      sugar_g: json['sugar_g'] as String?,
      carbohydrates_total_g: json['carbohydrates_total_g'] as String?,
    );

Map<String, dynamic> _$$NutrationImplToJson(_$NutrationImpl instance) =>
    <String, dynamic>{
      'calories': instance.calories,
      'serving_size_g': instance.serving_size_g,
      'fat_total_g': instance.fat_total_g,
      'fat_saturated_g': instance.fat_saturated_g,
      'protein_g': instance.protein_g,
      'sodium_mg': instance.sodium_mg,
      'potassium_mg': instance.potassium_mg,
      'cholesterol_mg': instance.cholesterol_mg,
      'fiber_g': instance.fiber_g,
      'sugar_g': instance.sugar_g,
      'carbohydrates_total_g': instance.carbohydrates_total_g,
    };
