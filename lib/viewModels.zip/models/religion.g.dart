// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'religion.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$ReligionImpl _$$ReligionImplFromJson(Map<String, dynamic> json) =>
    _$ReligionImpl(
      id: (json['id'] as num).toInt(),
      name: json['name'] as String,
    );

Map<String, dynamic> _$$ReligionImplToJson(_$ReligionImpl instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
    };
