// import 'package:flutter/material.dart';

// class Itemslist {
//   String tag;
//   String purchased;
//   String pending;
//   String shared;

//   Itemslist({required this.tag, required t})
// }
