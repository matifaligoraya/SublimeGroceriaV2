part of 'theme_cubit.dart';

abstract class ThemeState {
  const ThemeState();
}

class ThemeLight extends ThemeState {}

class ThemeDark extends ThemeState {}
