// ignore_for_file: constant_identifier_names

class Images {
  // static const String LOGO = 'assets/images/logo.png';
  static const String LOGO = 'assets/images/logo.png';
}
